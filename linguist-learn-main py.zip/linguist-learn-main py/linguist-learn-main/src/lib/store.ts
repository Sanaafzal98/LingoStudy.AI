import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { LangCode } from "./languages";

export interface GlossaryItem { term: string; translation: string; meaning: string; }
export interface Flashcard { id: string; front: string; back: string; status: "new" | "mastered" | "review"; }
export interface QuizQuestion { id: string; question: string; options: string[]; correctIndex: number; explanation: string; }
export interface ChatMessage { id: string; role: "user" | "assistant"; content: string; }

interface UserSettings {
  apiKey: string;
  provider: "lovable" | "openai" | "gemini";
}

interface StudyState {
  // Document
  pdfName: string | null;
  pdfText: string | null;
  language: LangCode;

  // AI outputs
  summary: string | null;
  glossary: GlossaryItem[];
  flashcards: Flashcard[];
  quiz: QuizQuestion[];
  chat: ChatMessage[];

  // Loading
  loading: { summary: boolean; glossary: boolean; flashcards: boolean; quiz: boolean; chat: boolean };

  // Quiz progress
  quizAnswers: Record<string, number>;
  quizScores: { date: number; score: number; total: number }[];

  // Settings
  settings: UserSettings;
  theme: "light" | "dark";

  // Actions
  setDocument: (name: string, text: string) => void;
  setLanguage: (l: LangCode) => void;
  setSummary: (s: string) => void;
  setGlossary: (g: GlossaryItem[]) => void;
  setFlashcards: (f: Flashcard[]) => void;
  updateFlashcardStatus: (id: string, status: Flashcard["status"]) => void;
  setQuiz: (q: QuizQuestion[]) => void;
  answerQuiz: (id: string, idx: number) => void;
  recordQuizScore: (score: number, total: number) => void;
  addChat: (m: ChatMessage) => void;
  setLoading: (k: keyof StudyState["loading"], v: boolean) => void;
  setSettings: (s: Partial<UserSettings>) => void;
  toggleTheme: () => void;
  reset: () => void;
}

export const useStore = create<StudyState>()(
  persist(
    (set) => ({
      pdfName: null,
      pdfText: null,
      language: "en",
      summary: null,
      glossary: [],
      flashcards: [],
      quiz: [],
      chat: [],
      loading: { summary: false, glossary: false, flashcards: false, quiz: false, chat: false },
      quizAnswers: {},
      quizScores: [],
      settings: { apiKey: "", provider: "lovable" },
      theme: "light",

      setDocument: (pdfName, pdfText) =>
        set({ pdfName, pdfText, summary: null, glossary: [], flashcards: [], quiz: [], chat: [], quizAnswers: {} }),
      setLanguage: (language) => set({ language }),
      setSummary: (summary) => set({ summary }),
      setGlossary: (glossary) => set({ glossary }),
      setFlashcards: (flashcards) => set({ flashcards }),
      updateFlashcardStatus: (id, status) =>
        set((s) => ({ flashcards: s.flashcards.map((f) => (f.id === id ? { ...f, status } : f)) })),
      setQuiz: (quiz) => set({ quiz, quizAnswers: {} }),
      answerQuiz: (id, idx) => set((s) => ({ quizAnswers: { ...s.quizAnswers, [id]: idx } })),
      recordQuizScore: (score, total) =>
        set((s) => ({ quizScores: [...s.quizScores, { date: Date.now(), score, total }] })),
      addChat: (m) => set((s) => ({ chat: [...s.chat, m] })),
      setLoading: (k, v) => set((s) => ({ loading: { ...s.loading, [k]: v } })),
      setSettings: (n) => set((s) => ({ settings: { ...s.settings, ...n } })),
      toggleTheme: () =>
        set((s) => {
          const theme = s.theme === "light" ? "dark" : "light";
          if (typeof document !== "undefined") {
            document.documentElement.classList.toggle("dark", theme === "dark");
          }
          return { theme };
        }),
      reset: () =>
        set({ pdfName: null, pdfText: null, summary: null, glossary: [], flashcards: [], quiz: [], chat: [], quizAnswers: {} }),
    }),
    {
      name: "global-study-ai",
      partialize: (s) => ({
        language: s.language,
        settings: s.settings,
        theme: s.theme,
        quizScores: s.quizScores,
      }),
    },
  ),
);
