import { createOpenAICompatible } from "@ai-sdk/openai-compatible";
import { createServerFn } from "@tanstack/react-start";
import { generateText } from "ai";
import { z } from "zod";
import { createLovableAiGatewayProvider } from "./ai-gateway.server";

const MODEL = "google/gemini-3-flash-preview";
const MAX_DOC = 50000;

function getModel(userKey?: string, provider?: string) {
  if (userKey && provider === "openai") {
    return createOpenAICompatible({
      name: "openai",
      baseURL: "https://api.openai.com/v1",
      headers: { Authorization: `Bearer ${userKey}` },
    })("gpt-4o-mini");
  }
  const key = process.env.LOVABLE_API_KEY;
  if (!key) throw new Error("Missing LOVABLE_API_KEY");
  return createLovableAiGatewayProvider(key)(MODEL);
}

const LANG_NAMES: Record<string, string> = {
  en: "English", de: "German", fr: "French", es: "Spanish", ar: "Arabic",
  zh: "Chinese (Simplified)", ja: "Japanese", ur: "Urdu", sd: "Sindhi", tr: "Turkish",
};

function langInstruction(lang: string) {
  const name = LANG_NAMES[lang] ?? "English";
  return `CRITICAL: Respond ENTIRELY in ${name}. Every sentence, label, and word must be in ${name}. Do not mix languages. This is non-negotiable.`;
}

function extractJson(raw: string): unknown {
  let s = raw.replace(/```json\s*/gi, "").replace(/```\s*/g, "").trim();
  const startObj = s.indexOf("{");
  const startArr = s.indexOf("[");
  let start = -1;
  let endChar = "";
  if (startObj === -1 && startArr === -1) throw new Error("No JSON found");
  if (startArr === -1 || (startObj !== -1 && startObj < startArr)) { start = startObj; endChar = "}"; }
  else { start = startArr; endChar = "]"; }
  const end = s.lastIndexOf(endChar);
  if (end === -1 || end < start) throw new Error("Incomplete JSON");
  s = s.substring(start, end + 1);
  try { return JSON.parse(s); }
  catch {
    s = s.replace(/,\s*}/g, "}").replace(/,\s*]/g, "]").replace(/[\x00-\x1F\x7F]/g, (c) => c === "\n" || c === "\t" ? c : "");
    return JSON.parse(s);
  }
}

async function generateJson<T>(opts: { model: ReturnType<typeof getModel>; system: string; prompt: string; schema: z.ZodSchema<T> }): Promise<T> {
  const { text } = await generateText({
    model: opts.model,
    system: opts.system + "\n\nOutput ONLY valid JSON matching the requested schema. No prose, no markdown fences, no comments.",
    prompt: opts.prompt,
  });
  const parsed = extractJson(text);
  return opts.schema.parse(parsed);
}

const BaseInput = z.object({
  text: z.string().min(1).max(MAX_DOC),
  language: z.string().min(2).max(5),
  userKey: z.string().optional(),
  provider: z.string().optional(),
});

export const generateSummary = createServerFn({ method: "POST" })
  .inputValidator((i: unknown) => BaseInput.parse(i))
  .handler(async ({ data }) => {
    const { text: t } = await generateText({
      model: getModel(data.userKey, data.provider),
      system: `You are an expert academic summarizer. ${langInstruction(data.language)}`,
      prompt: `Provide a concise, well-structured executive summary (4-6 paragraphs) of this document. Use markdown headings (##) for key sections. Highlight main thesis, methodology, key findings, and implications.\n\nDOCUMENT:\n${data.text.slice(0, MAX_DOC)}`,
    });
    return { summary: t };
  });

export const generateGlossary = createServerFn({ method: "POST" })
  .inputValidator((i: unknown) => BaseInput.parse(i))
  .handler(async ({ data }) => {
    const schema = z.object({
      glossary: z.array(z.object({ term: z.string(), translation: z.string(), meaning: z.string() })),
    });
    const out = await generateJson({
      model: getModel(data.userKey, data.provider),
      system: `You extract technical terms and translate them. ${langInstruction(data.language)} except keep the original English term in 'term'.`,
      prompt: `From the document, extract 12 difficult technical/academic English terms. For each, provide a translation and a contextual meaning in ${LANG_NAMES[data.language]}.\n\nReturn JSON of shape: {"glossary":[{"term":"...","translation":"...","meaning":"..."}]}\n\nDOCUMENT:\n${data.text.slice(0, MAX_DOC)}`,
      schema,
    });
    return { glossary: out.glossary };
  });

export const generateFlashcards = createServerFn({ method: "POST" })
  .inputValidator((i: unknown) => BaseInput.parse(i))
  .handler(async ({ data }) => {
    const schema = z.object({
      cards: z.array(z.object({ front: z.string(), back: z.string() })),
    });
    const out = await generateJson({
      model: getModel(data.userKey, data.provider),
      system: `You create study flashcards. ${langInstruction(data.language)}`,
      prompt: `Create 10 flashcards for key concepts from the document. 'front' is a concept/question, 'back' is a clear explanation. Both in ${LANG_NAMES[data.language]}.\n\nReturn JSON of shape: {"cards":[{"front":"...","back":"..."}]}\n\nDOCUMENT:\n${data.text.slice(0, MAX_DOC)}`,
      schema,
    });
    return { cards: out.cards };
  });

export const generateQuiz = createServerFn({ method: "POST" })
  .inputValidator((i: unknown) => BaseInput.parse(i))
  .handler(async ({ data }) => {
    const schema = z.object({
      questions: z.array(z.object({
        question: z.string(),
        options: z.array(z.string()),
        correctIndex: z.number().int().min(0).max(3),
        explanation: z.string(),
      })),
    });
    const out = await generateJson({
      model: getModel(data.userKey, data.provider),
      system: `You create educational MCQ quizzes. ${langInstruction(data.language)}`,
      prompt: `Create exactly 5 multiple-choice questions based on the document. Each has exactly 4 options, one correct (correctIndex 0-3), and an 'explanation' detailing why the correct answer is right. ALL fields in ${LANG_NAMES[data.language]}.\n\nReturn JSON of shape: {"questions":[{"question":"...","options":["a","b","c","d"],"correctIndex":0,"explanation":"..."}]}\n\nDOCUMENT:\n${data.text.slice(0, MAX_DOC)}`,
      schema,
    });
    const questions = out.questions.filter((q) => q.options.length === 4).slice(0, 5);
    return { questions };
  });

const ChatInput = z.object({
  text: z.string().min(1).max(MAX_DOC),
  language: z.string().min(2).max(5),
  question: z.string().min(1).max(2000),
  history: z.array(z.object({ role: z.enum(["user", "assistant"]), content: z.string().max(4000) })).max(20).default([]),
  userKey: z.string().optional(),
  provider: z.string().optional(),
});

export const chatWithDocument = createServerFn({ method: "POST" })
  .inputValidator((i: unknown) => ChatInput.parse(i))
  .handler(async ({ data }) => {
    const { text } = await generateText({
      model: getModel(data.userKey, data.provider),
      system: `You are a patient, expert tutor answering questions about a specific document. Use only the document as your source. ${langInstruction(data.language)} regardless of the language the user writes in. Be thorough, educational, and use markdown formatting (headings, lists, bold).`,
      messages: [
        { role: "user", content: `DOCUMENT CONTEXT:\n${data.text.slice(0, MAX_DOC)}` },
        ...data.history.map((m) => ({ role: m.role, content: m.content })),
        { role: "user", content: data.question },
      ],
    });
    return { answer: text };
  });
