export type LangCode =
  | "en" | "de" | "fr" | "es" | "ar" | "zh" | "ja" | "ur" | "sd" | "tr";

export interface LanguageDef {
  code: LangCode;
  name: string;
  nativeName: string;
  flag: string;
  bcp47: string; // for Web Speech API
  rtl?: boolean;
}

export const LANGUAGES: LanguageDef[] = [
  { code: "en", name: "English", nativeName: "English", flag: "🇬🇧", bcp47: "en-US" },
  { code: "de", name: "German", nativeName: "Deutsch", flag: "🇩🇪", bcp47: "de-DE" },
  { code: "fr", name: "French", nativeName: "Français", flag: "🇫🇷", bcp47: "fr-FR" },
  { code: "es", name: "Spanish", nativeName: "Español", flag: "🇪🇸", bcp47: "es-ES" },
  { code: "ar", name: "Arabic", nativeName: "العربية", flag: "🇸🇦", bcp47: "ar-SA", rtl: true },
  { code: "zh", name: "Chinese", nativeName: "中文", flag: "🇨🇳", bcp47: "zh-CN" },
  { code: "ja", name: "Japanese", nativeName: "日本語", flag: "🇯🇵", bcp47: "ja-JP" },
  { code: "ur", name: "Urdu", nativeName: "اردو", flag: "🇵🇰", bcp47: "ur-PK", rtl: true },
  { code: "sd", name: "Sindhi", nativeName: "سنڌي", flag: "🇵🇰", bcp47: "sd-PK", rtl: true },
  { code: "tr", name: "Turkish", nativeName: "Türkçe", flag: "🇹🇷", bcp47: "tr-TR" },
];

export const getLanguage = (code: LangCode): LanguageDef =>
  LANGUAGES.find((l) => l.code === code) ?? LANGUAGES[0];
