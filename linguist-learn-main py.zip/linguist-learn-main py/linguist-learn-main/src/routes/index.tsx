import { createFileRoute } from "@tanstack/react-router";
import { Dashboard } from "@/components/Dashboard";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Global-Study AI — Multilingual PDF Study Companion" },
      { name: "description", content: "Upload research papers and study them in 10+ languages with AI-powered summaries, flashcards, quizzes, and voice tutoring." },
    ],
  }),
  component: Dashboard,
});
