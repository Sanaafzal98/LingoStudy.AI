import { FileText, Loader2, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useStore } from "@/lib/store";
import { useServerFn } from "@tanstack/react-start";
import { generateSummary } from "@/lib/ai.functions";
import { toast } from "sonner";
import { Markdown } from "./Markdown";
import { SpeakButton } from "./SpeakButton";
import { getLanguage } from "@/lib/languages";

export function SummaryCard() {
  const { pdfText, summary, setSummary, language, loading, setLoading, settings } = useStore();
  const run = useServerFn(generateSummary);
  const lang = getLanguage(language);

  const gen = async () => {
    if (!pdfText) return;
    setLoading("summary", true);
    try {
      const { summary: s } = await run({
        data: { text: pdfText, language, userKey: settings.apiKey || undefined, provider: settings.provider },
      });
      setSummary(s);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed");
    } finally {
      setLoading("summary", false);
    }
  };

  return (
    <div className="bg-card border border-border rounded-xl p-5">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold flex items-center gap-2"><FileText className="h-4 w-4 text-primary" /> Executive Summary</h3>
        <Button size="sm" onClick={gen} disabled={!pdfText || loading.summary} className="bg-gradient-primary text-primary-foreground">
          {loading.summary ? <Loader2 className="h-3 w-3 animate-spin" /> : <Sparkles className="h-3 w-3" />}
          <span className="ml-1">{summary ? "Regenerate" : "Generate"}</span>
        </Button>
      </div>
      {summary ? (
        <div dir={lang.rtl ? "rtl" : "ltr"}>
          <Markdown content={summary} />
          <SpeakButton text={summary} />
        </div>
      ) : (
        <p className="text-sm text-muted-foreground">{pdfText ? "Click Generate to summarize in " + lang.name : "Upload a PDF to begin."}</p>
      )}
    </div>
  );
}
