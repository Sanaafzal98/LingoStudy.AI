import { useState } from "react";
import { Settings, Key, Eye, EyeOff } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useStore } from "@/lib/store";
import { toast } from "sonner";

export function SettingsModal() {
  const { settings, setSettings } = useStore();
  const [open, setOpen] = useState(false);
  const [show, setShow] = useState(false);
  const [key, setKey] = useState(settings.apiKey);
  const [provider, setProvider] = useState(settings.provider);

  const save = () => {
    setSettings({ apiKey: key.trim(), provider });
    toast.success("Settings saved");
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" className="h-9 w-9">
          <Settings className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><Key className="h-4 w-4" /> API Settings</DialogTitle>
          <DialogDescription>
            By default, Global-Study uses the built-in Lovable AI Gateway. Optionally paste your own OpenAI key.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label className="mb-2 block">Provider</Label>
            <RadioGroup value={provider} onValueChange={(v) => setProvider(v as typeof provider)}>
              <div className="flex items-center gap-2"><RadioGroupItem value="lovable" id="p1" /><Label htmlFor="p1">Lovable AI (default, no key needed)</Label></div>
              <div className="flex items-center gap-2"><RadioGroupItem value="openai" id="p2" /><Label htmlFor="p2">OpenAI (your key)</Label></div>
            </RadioGroup>
          </div>
          {provider === "openai" && (
            <div>
              <Label className="mb-2 block">OpenAI API Key</Label>
              <div className="relative">
                <Input
                  type={show ? "text" : "password"}
                  value={key}
                  onChange={(e) => setKey(e.target.value)}
                  placeholder="sk-..."
                  className="pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShow(!show)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground"
                >
                  {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              <p className="text-xs text-muted-foreground mt-1">Stored only in your browser.</p>
            </div>
          )}
          <Button onClick={save} className="w-full bg-gradient-primary text-primary-foreground">Save Settings</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
