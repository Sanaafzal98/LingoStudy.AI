import { useState } from "react";
import { Layers, Loader2, Sparkles, Check, RotateCcw, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useStore } from "@/lib/store";
import { useServerFn } from "@tanstack/react-start";
import { generateFlashcards } from "@/lib/ai.functions";
import { toast } from "sonner";
import { getLanguage } from "@/lib/languages";

export function FlashcardsCard() {
  const { pdfText, flashcards, setFlashcards, updateFlashcardStatus, language, loading, setLoading, settings } = useStore();
  const run = useServerFn(generateFlashcards);
  const [idx, setIdx] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const lang = getLanguage(language);

  const gen = async () => {
    if (!pdfText) return;
    setLoading("flashcards", true);
    try {
      const { cards } = await run({
        data: { text: pdfText, language, userKey: settings.apiKey || undefined, provider: settings.provider },
      });
      setFlashcards(cards.map((c) => ({ id: crypto.randomUUID(), front: c.front, back: c.back, status: "new" })));
      setIdx(0); setFlipped(false);
    } catch (e) { toast.error(e instanceof Error ? e.message : "Failed"); }
    finally { setLoading("flashcards", false); }
  };

  const card = flashcards[idx];
  const mastered = flashcards.filter((f) => f.status === "mastered").length;

  return (
    <div className="bg-card border border-border rounded-xl p-5">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold flex items-center gap-2"><Layers className="h-4 w-4 text-primary" /> Flashcards</h3>
        <Button size="sm" onClick={gen} disabled={!pdfText || loading.flashcards} className="bg-gradient-primary text-primary-foreground">
          {loading.flashcards ? <Loader2 className="h-3 w-3 animate-spin" /> : <Sparkles className="h-3 w-3" />}
          <span className="ml-1">{flashcards.length ? "New Set" : "Generate"}</span>
        </Button>
      </div>

      {card ? (
        <div>
          <div className="flex items-center justify-between text-xs text-muted-foreground mb-2">
            <span>{idx + 1} / {flashcards.length}</span>
            <span>Mastered {mastered}/{flashcards.length}</span>
          </div>
          <div className={`flip-card h-48 cursor-pointer ${flipped ? "flipped" : ""}`} onClick={() => setFlipped(!flipped)}>
            <div className="flip-card-inner w-full h-full">
              <div className="flip-face w-full h-full rounded-xl bg-gradient-primary text-primary-foreground p-5 flex items-center justify-center text-center shadow-elegant">
                <p className="font-semibold text-base" dir={lang.rtl ? "rtl" : "ltr"}>{card.front}</p>
              </div>
              <div className="flip-face flip-back w-full h-full rounded-xl bg-card border-2 border-primary p-5 flex items-center justify-center text-center overflow-auto">
                <p className="text-sm" dir={lang.rtl ? "rtl" : "ltr"}>{card.back}</p>
              </div>
            </div>
          </div>
          <p className="text-xs text-center text-muted-foreground mt-2">Tap card to flip</p>
          <div className="flex items-center gap-2 mt-3">
            <Button size="icon" variant="outline" onClick={() => { setIdx((i) => Math.max(0, i - 1)); setFlipped(false); }} disabled={idx === 0}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button size="sm" variant="outline" onClick={() => updateFlashcardStatus(card.id, "review")} className="flex-1">
              <RotateCcw className="h-3 w-3 mr-1" /> Review
            </Button>
            <Button size="sm" onClick={() => updateFlashcardStatus(card.id, "mastered")} className="flex-1 bg-success text-success-foreground hover:bg-success/90">
              <Check className="h-3 w-3 mr-1" /> Mastered
            </Button>
            <Button size="icon" variant="outline" onClick={() => { setIdx((i) => Math.min(flashcards.length - 1, i + 1)); setFlipped(false); }} disabled={idx >= flashcards.length - 1}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      ) : (
        <p className="text-sm text-muted-foreground">Generate flippable study cards in {lang.name}.</p>
      )}
    </div>
  );
}
