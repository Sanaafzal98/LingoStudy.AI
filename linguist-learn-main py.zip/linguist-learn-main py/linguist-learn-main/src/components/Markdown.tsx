// Lightweight markdown renderer (no extra deps) — supports headings, bold, italic, lists, code, paragraphs.
export function Markdown({ content }: { content: string }) {
  const lines = content.split("\n");
  const blocks: React.ReactNode[] = [];
  let listBuf: string[] = [];
  let key = 0;

  const inline = (s: string) =>
    s
      .replace(/`([^`]+)`/g, '<code class="px-1 py-0.5 rounded bg-muted text-xs font-mono">$1</code>')
      .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
      .replace(/\*([^*]+)\*/g, "<em>$1</em>");

  const flushList = () => {
    if (listBuf.length) {
      blocks.push(
        <ul key={key++} className="list-disc pl-5 space-y-1 text-sm">
          {listBuf.map((it, i) => (
            <li key={i} dangerouslySetInnerHTML={{ __html: inline(it) }} />
          ))}
        </ul>,
      );
      listBuf = [];
    }
  };

  for (const raw of lines) {
    const line = raw.trim();
    if (!line) { flushList(); continue; }
    if (line.startsWith("### ")) { flushList(); blocks.push(<h4 key={key++} className="font-semibold text-sm mt-3">{line.slice(4)}</h4>); }
    else if (line.startsWith("## ")) { flushList(); blocks.push(<h3 key={key++} className="font-semibold text-base mt-3">{line.slice(3)}</h3>); }
    else if (line.startsWith("# ")) { flushList(); blocks.push(<h2 key={key++} className="font-bold text-lg mt-3">{line.slice(2)}</h2>); }
    else if (/^[-*]\s+/.test(line)) { listBuf.push(line.replace(/^[-*]\s+/, "")); }
    else if (/^\d+\.\s+/.test(line)) { listBuf.push(line.replace(/^\d+\.\s+/, "")); }
    else {
      flushList();
      blocks.push(<p key={key++} className="text-sm leading-relaxed" dangerouslySetInnerHTML={{ __html: inline(line) }} />);
    }
  }
  flushList();
  return <div className="space-y-2 max-w-none">{blocks}</div>;
}
