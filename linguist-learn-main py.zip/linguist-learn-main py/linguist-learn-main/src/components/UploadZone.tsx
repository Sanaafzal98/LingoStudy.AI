import { useCallback, useRef, useState } from "react";
import { Upload, FileText, X, Loader2 } from "lucide-react";
import { useStore } from "@/lib/store";
import { extractPdfText } from "@/lib/pdf";
import { toast } from "sonner";

export function UploadZone() {
  const { pdfName, setDocument, reset } = useStore();
  const [dragging, setDragging] = useState(false);
  const [loading, setLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = useCallback(async (file: File) => {
    if (!file.name.toLowerCase().endsWith(".pdf")) {
      toast.error("Please upload a PDF file");
      return;
    }
    if (file.size > 20 * 1024 * 1024) {
      toast.error("File too large (max 20MB)");
      return;
    }
    setLoading(true);
    try {
      const text = await extractPdfText(file);
      if (text.length < 100) throw new Error("PDF text could not be extracted");
      setDocument(file.name, text);
      toast.success(`Loaded: ${file.name}`);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to read PDF");
    } finally {
      setLoading(false);
    }
  }, [setDocument]);

  return (
    <div className="space-y-2">
      {pdfName ? (
        <div className="flex items-center gap-2 p-3 rounded-lg bg-accent/50 border border-border">
          <FileText className="h-5 w-5 text-primary shrink-0" />
          <span className="text-sm truncate flex-1">{pdfName}</span>
          <button onClick={reset} className="text-muted-foreground hover:text-destructive">
            <X className="h-4 w-4" />
          </button>
        </div>
      ) : (
        <div
          onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
          onDragLeave={() => setDragging(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragging(false);
            const f = e.dataTransfer.files[0];
            if (f) handleFile(f);
          }}
          onClick={() => inputRef.current?.click()}
          className={`cursor-pointer rounded-xl border-2 border-dashed p-6 text-center transition-all ${
            dragging ? "border-primary bg-primary/10 shadow-glow" : "border-border hover:border-primary/50 hover:bg-accent/30"
          }`}
        >
          {loading ? (
            <Loader2 className="h-8 w-8 mx-auto animate-spin text-primary" />
          ) : (
            <Upload className="h-8 w-8 mx-auto text-primary mb-2" />
          )}
          <p className="text-sm font-medium mt-2">{loading ? "Reading PDF..." : "Drop PDF here"}</p>
          <p className="text-xs text-muted-foreground mt-1">or click to browse</p>
          <input
            ref={inputRef}
            type="file"
            accept="application/pdf"
            className="hidden"
            onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
          />
        </div>
      )}
    </div>
  );
}
