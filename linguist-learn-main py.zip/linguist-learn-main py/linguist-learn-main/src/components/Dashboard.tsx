import { Globe2 } from "lucide-react";
import { UploadZone } from "@/components/UploadZone";
import { LanguageSelector } from "@/components/LanguageSelector";
import { SettingsModal } from "@/components/SettingsModal";
import { ThemeToggle } from "@/components/ThemeToggle";
import { ExportButton } from "@/components/ExportButton";
import { SummaryCard } from "@/components/SummaryCard";
import { GlossaryCard } from "@/components/GlossaryCard";
import { FlashcardsCard } from "@/components/FlashcardsCard";
import { ProgressCard } from "@/components/ProgressCard";
import { ChatPanel } from "@/components/ChatPanel";
import { QuizCard } from "@/components/QuizCard";
import { ThemeInit } from "@/components/ThemeInit";
import { Toaster } from "@/components/ui/sonner";

export function Dashboard() {
  return (
    <>
      <ThemeInit />
      <Toaster position="top-right" />
      <div className="min-h-screen bg-background flex">
        {/* Sidebar */}
        <aside className="w-80 shrink-0 border-r border-sidebar-border bg-sidebar flex flex-col h-screen sticky top-0">
          <div className="p-5 border-b border-sidebar-border">
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2">
                <div className="h-9 w-9 rounded-lg bg-gradient-primary flex items-center justify-center shadow-elegant">
                  <Globe2 className="h-5 w-5 text-primary-foreground" />
                </div>
                <div>
                  <h1 className="font-bold text-base leading-tight text-gradient">Global-Study AI</h1>
                  <p className="text-[10px] text-muted-foreground">Multilingual Study Companion</p>
                </div>
              </div>
              <div className="flex">
                <ThemeToggle />
                <SettingsModal />
              </div>
            </div>
          </div>

          <div className="p-5 space-y-5 overflow-y-auto flex-1">
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2 block">Document</label>
              <UploadZone />
            </div>
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2 block">Study Language</label>
              <LanguageSelector />
            </div>
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2 block">Export</label>
              <ExportButton />
            </div>

            <div className="p-3 rounded-lg bg-gradient-subtle border border-border text-xs text-muted-foreground">
              <p className="font-semibold text-foreground mb-1">💡 Pro Tip</p>
              <p>Use the microphone in chat to ask questions in your target language and practice pronunciation with audio responses.</p>
            </div>
          </div>

          <div className="p-4 border-t border-sidebar-border text-[10px] text-muted-foreground text-center">
            Powered by Sana Afzal
          </div>
        </aside>

        {/* Main */}
        <main className="flex-1 p-6 overflow-x-hidden">
          <div className="max-w-[1600px] mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left column: Analytics & Learning Tools */}
            <div className="space-y-6 lg:col-span-1">
              <SummaryCard />
              <GlossaryCard />
            </div>
            {/* Middle: Chat */}
            <div className="lg:col-span-1 h-[calc(100vh-3rem)] min-h-[600px]">
              <ChatPanel />
            </div>
            {/* Right: Tools */}
            <div className="space-y-6 lg:col-span-1">
              <ProgressCard />
              <FlashcardsCard />
              <QuizCard />
            </div>
          </div>
        </main>
      </div>
    </>
  );
}
