import { useState } from "react";
import { GraduationCap, Loader2, Sparkles, Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useStore } from "@/lib/store";
import { useServerFn } from "@tanstack/react-start";
import { generateQuiz } from "@/lib/ai.functions";
import { toast } from "sonner";
import { getLanguage } from "@/lib/languages";

export function QuizCard() {
  const { pdfText, quiz, setQuiz, quizAnswers, answerQuiz, recordQuizScore, language, loading, setLoading, settings } = useStore();
  const run = useServerFn(generateQuiz);
  const [submitted, setSubmitted] = useState(false);
  const lang = getLanguage(language);

  const gen = async () => {
    if (!pdfText) return;
    setLoading("quiz", true);
    setSubmitted(false);
    try {
      const { questions } = await run({
        data: { text: pdfText, language, userKey: settings.apiKey || undefined, provider: settings.provider },
      });
      setQuiz(questions.map((q) => ({ id: crypto.randomUUID(), ...q })));
    } catch (e) { toast.error(e instanceof Error ? e.message : "Failed"); }
    finally { setLoading("quiz", false); }
  };

  const submit = () => {
    const score = quiz.filter((q) => quizAnswers[q.id] === q.correctIndex).length;
    recordQuizScore(score, quiz.length);
    setSubmitted(true);
    toast.success(`Score: ${score}/${quiz.length}`);
  };

  const allAnswered = quiz.length > 0 && quiz.every((q) => quizAnswers[q.id] !== undefined);

  return (
    <div className="bg-card border border-border rounded-xl p-5">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold flex items-center gap-2"><GraduationCap className="h-4 w-4 text-primary" /> Assessment Hub</h3>
        <Button size="sm" onClick={gen} disabled={!pdfText || loading.quiz} className="bg-gradient-primary text-primary-foreground">
          {loading.quiz ? <Loader2 className="h-3 w-3 animate-spin" /> : <Sparkles className="h-3 w-3" />}
          <span className="ml-1">{quiz.length ? "New Quiz" : "Generate Quiz"}</span>
        </Button>
      </div>

      {quiz.length > 0 ? (
        <div className="space-y-4 max-h-[28rem] overflow-y-auto pr-2" dir={lang.rtl ? "rtl" : "ltr"}>
          {quiz.map((q, qi) => {
            const userAns = quizAnswers[q.id];
            return (
              <div key={q.id} className="p-3 rounded-lg bg-muted/40">
                <p className="font-medium text-sm mb-2">{qi + 1}. {q.question}</p>
                <div className="space-y-1">
                  {q.options.map((opt, oi) => {
                    const isCorrect = submitted && oi === q.correctIndex;
                    const isWrongPick = submitted && userAns === oi && oi !== q.correctIndex;
                    return (
                      <button
                        key={oi}
                        disabled={submitted}
                        onClick={() => answerQuiz(q.id, oi)}
                        className={`w-full text-left px-3 py-2 rounded-md text-sm border transition-colors ${
                          isCorrect ? "bg-success/20 border-success text-foreground" :
                          isWrongPick ? "bg-destructive/20 border-destructive text-foreground" :
                          userAns === oi ? "bg-primary/15 border-primary" :
                          "bg-card border-border hover:border-primary/40"
                        }`}
                      >
                        <span className="font-mono text-xs mr-2">{String.fromCharCode(65 + oi)}.</span>
                        {opt}
                        {isCorrect && <Check className="inline ml-2 h-3 w-3" />}
                        {isWrongPick && <X className="inline ml-2 h-3 w-3" />}
                      </button>
                    );
                  })}
                </div>
                {submitted && (
                  <div className="mt-2 p-2 rounded bg-accent/40 text-xs">
                    <strong>Explanation:</strong> {q.explanation}
                  </div>
                )}
              </div>
            );
          })}
          {!submitted && (
            <Button onClick={submit} disabled={!allAnswered} className="w-full bg-gradient-primary text-primary-foreground">
              Submit Quiz
            </Button>
          )}
        </div>
      ) : (
        <p className="text-sm text-muted-foreground">Generate 5 MCQs in {lang.name} to test your understanding.</p>
      )}
    </div>
  );
}
