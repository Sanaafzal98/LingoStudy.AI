import { TrendingUp, Award, BookCheck, Brain } from "lucide-react";
import { useStore } from "@/lib/store";

export function ProgressCard() {
  const { flashcards, quizScores, pdfText } = useStore();
  const mastered = flashcards.filter((f) => f.status === "mastered").length;
  const reviewing = flashcards.filter((f) => f.status === "review").length;
  const masteryPct = flashcards.length ? Math.round((mastered / flashcards.length) * 100) : 0;
  const avgScore = quizScores.length
    ? Math.round(quizScores.reduce((a, b) => a + (b.score / b.total) * 100, 0) / quizScores.length)
    : 0;
  const readingPct = pdfText ? Math.min(100, Math.round(((mastered * 5) + (quizScores.length * 15)) )) : 0;

  const stats = [
    { label: "Mastery", value: `${masteryPct}%`, icon: Brain, color: "text-primary" },
    { label: "Avg Quiz", value: `${avgScore}%`, icon: Award, color: "text-success" },
    { label: "Mastered", value: `${mastered}`, icon: BookCheck, color: "text-primary-glow" },
    { label: "Reviewing", value: `${reviewing}`, icon: TrendingUp, color: "text-warning" },
  ];

  return (
    <div className="bg-card border border-border rounded-xl p-5">
      <h3 className="font-semibold flex items-center gap-2 mb-3"><TrendingUp className="h-4 w-4 text-primary" /> Progress & Analytics</h3>
      <div className="grid grid-cols-2 gap-3">
        {stats.map((s) => (
          <div key={s.label} className="p-3 rounded-lg bg-gradient-subtle border border-border">
            <div className="flex items-center gap-2 text-xs text-muted-foreground"><s.icon className={`h-3.5 w-3.5 ${s.color}`} /> {s.label}</div>
            <p className={`text-2xl font-bold mt-1 ${s.color}`}>{s.value}</p>
          </div>
        ))}
      </div>
      <div className="mt-4">
        <div className="flex justify-between text-xs mb-1">
          <span className="text-muted-foreground">Reading Completion</span>
          <span className="font-medium">{readingPct}%</span>
        </div>
        <div className="h-2 rounded-full bg-muted overflow-hidden">
          <div className="h-full bg-gradient-primary transition-all" style={{ width: `${readingPct}%` }} />
        </div>
      </div>
      {quizScores.length > 0 && (
        <div className="mt-4">
          <p className="text-xs text-muted-foreground mb-2">Recent Quizzes</p>
          <div className="flex gap-1 items-end h-12">
            {quizScores.slice(-10).map((s, i) => {
              const pct = (s.score / s.total) * 100;
              return (
                <div key={i} className="flex-1 bg-gradient-primary rounded-t" style={{ height: `${Math.max(8, pct)}%` }} title={`${s.score}/${s.total}`} />
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
