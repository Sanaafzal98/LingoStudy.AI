import { useState, useRef, useEffect } from "react";
import { Send, Mic, MicOff, Sparkles, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useStore, type ChatMessage } from "@/lib/store";
import { useServerFn } from "@tanstack/react-start";
import { chatWithDocument } from "@/lib/ai.functions";
import { getLanguage } from "@/lib/languages";
import { toast } from "sonner";
import { SpeakButton } from "./SpeakButton";
import { Markdown } from "./Markdown";

export function ChatPanel() {
  const { pdfText, language, chat, addChat, setLoading, loading, settings } = useStore();
  const callChat = useServerFn(chatWithDocument);
  const [input, setInput] = useState("");
  const [listening, setListening] = useState(false);
  const recRef = useRef<unknown>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [chat, loading.chat]);

  const startVoice = () => {
    const w = window as unknown as { SpeechRecognition?: new () => unknown; webkitSpeechRecognition?: new () => unknown };
    const SR = w.SpeechRecognition ?? w.webkitSpeechRecognition;
    if (!SR) { toast.error("Voice input not supported in this browser"); return; }
    if (listening) {
      (recRef.current as { stop: () => void } | null)?.stop();
      setListening(false);
      return;
    }
    const rec = new (SR as new () => {
      lang: string; continuous: boolean; interimResults: boolean;
      onresult: (e: { results: { 0: { transcript: string } }[] }) => void;
      onend: () => void; onerror: (e: { error: string }) => void;
      start: () => void; stop: () => void;
    })();
    rec.lang = getLanguage(language).bcp47;
    rec.continuous = false;
    rec.interimResults = false;
    rec.onresult = (e) => {
      const t = e.results[0][0].transcript;
      setInput((prev) => prev + (prev ? " " : "") + t);
    };
    rec.onend = () => setListening(false);
    rec.onerror = (e) => { toast.error("Voice error: " + e.error); setListening(false); };
    rec.start();
    recRef.current = rec;
    setListening(true);
  };

  const send = async () => {
    const q = input.trim();
    if (!q || !pdfText || loading.chat) return;
    const userMsg: ChatMessage = { id: crypto.randomUUID(), role: "user", content: q };
    addChat(userMsg);
    setInput("");
    setLoading("chat", true);
    try {
      const { answer } = await callChat({
        data: {
          text: pdfText, language, question: q,
          history: chat.slice(-10).map((m) => ({ role: m.role, content: m.content })),
          userKey: settings.apiKey || undefined, provider: settings.provider,
        },
      });
      addChat({ id: crypto.randomUUID(), role: "assistant", content: answer });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Chat failed");
    } finally {
      setLoading("chat", false);
    }
  };

  const langDef = getLanguage(language);

  return (
    <div className="flex flex-col h-full bg-card rounded-xl border border-border overflow-hidden">
      <div className="px-4 py-3 border-b border-border bg-gradient-subtle">
        <h3 className="font-semibold flex items-center gap-2"><MessageSquare className="h-4 w-4 text-primary" /> AI Tutor Chat</h3>
        <p className="text-xs text-muted-foreground">Responses in {langDef.name} {langDef.flag}</p>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4">
        {chat.length === 0 && !loading.chat && (
          <div className="text-center text-muted-foreground py-8">
            <Sparkles className="h-10 w-10 mx-auto mb-3 text-primary/50" />
            <p className="text-sm">Ask anything about your document.</p>
            <p className="text-xs mt-1">Try voice input with the mic button.</p>
          </div>
        )}
        {chat.map((m) => (
          <div key={m.id} className={m.role === "user" ? "flex justify-end" : ""}>
            {m.role === "user" ? (
              <div className="max-w-[85%] rounded-2xl rounded-tr-sm bg-primary text-primary-foreground px-4 py-2 text-sm">
                {m.content}
              </div>
            ) : (
              <div className="flex gap-2 items-start group" dir={langDef.rtl ? "rtl" : "ltr"}>
                <div className="h-8 w-8 rounded-full bg-gradient-primary shrink-0 flex items-center justify-center text-xs font-bold text-primary-foreground">AI</div>
                <div className="flex-1 min-w-0">
                  <Markdown content={m.content} />
                  <SpeakButton text={m.content} className="opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              </div>
            )}
          </div>
        ))}
        {loading.chat && (
          <div className="flex gap-2 items-center text-muted-foreground text-sm">
            <div className="h-8 w-8 rounded-full bg-gradient-primary flex items-center justify-center text-xs font-bold text-primary-foreground">AI</div>
            <div className="flex gap-1">
              <span className="h-2 w-2 rounded-full bg-primary animate-bounce" />
              <span className="h-2 w-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: "0.15s" }} />
              <span className="h-2 w-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: "0.3s" }} />
            </div>
          </div>
        )}
      </div>

      <div className="border-t border-border p-3 bg-background/50">
        <div className="flex gap-2 items-end">
          <Button
            type="button"
            variant={listening ? "default" : "outline"}
            size="icon"
            onClick={startVoice}
            disabled={!pdfText}
            className={listening ? "bg-destructive hover:bg-destructive/90" : ""}
            title="Voice input"
          >
            {listening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
          </Button>
          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
            placeholder={pdfText ? "Ask a question..." : "Upload a PDF first"}
            disabled={!pdfText || loading.chat}
            rows={1}
            className="min-h-[40px] max-h-32 resize-none"
          />
          <Button onClick={send} disabled={!input.trim() || !pdfText || loading.chat} size="icon" className="bg-gradient-primary text-primary-foreground">
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
