import { BookOpen, Loader2, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useStore } from "@/lib/store";
import { useServerFn } from "@tanstack/react-start";
import { generateGlossary } from "@/lib/ai.functions";
import { toast } from "sonner";
import { getLanguage } from "@/lib/languages";

export function GlossaryCard() {
  const { pdfText, glossary, setGlossary, language, loading, setLoading, settings } = useStore();
  const run = useServerFn(generateGlossary);
  const lang = getLanguage(language);

  const gen = async () => {
    if (!pdfText) return;
    setLoading("glossary", true);
    try {
      const { glossary: g } = await run({
        data: { text: pdfText, language, userKey: settings.apiKey || undefined, provider: settings.provider },
      });
      setGlossary(g);
    } catch (e) { toast.error(e instanceof Error ? e.message : "Failed"); }
    finally { setLoading("glossary", false); }
  };

  return (
    <div className="bg-card border border-border rounded-xl p-5">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold flex items-center gap-2"><BookOpen className="h-4 w-4 text-primary" /> Smart Glossary</h3>
        <Button size="sm" onClick={gen} disabled={!pdfText || loading.glossary} className="bg-gradient-primary text-primary-foreground">
          {loading.glossary ? <Loader2 className="h-3 w-3 animate-spin" /> : <Sparkles className="h-3 w-3" />}
          <span className="ml-1">{glossary.length ? "Regenerate" : "Extract"}</span>
        </Button>
      </div>
      {glossary.length > 0 ? (
        <div className="space-y-2 max-h-96 overflow-y-auto pr-2">
          {glossary.map((g, i) => (
            <div key={i} className="grid grid-cols-[1fr_1fr] gap-3 p-3 rounded-lg bg-muted/40 hover:bg-muted/60 transition-colors">
              <div>
                <p className="font-semibold text-sm">{g.term}</p>
                <p className="text-xs text-muted-foreground mt-1">English term</p>
              </div>
              <div dir={lang.rtl ? "rtl" : "ltr"}>
                <p className="font-semibold text-sm text-primary">{g.translation}</p>
                <p className="text-xs text-muted-foreground mt-1">{g.meaning}</p>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-sm text-muted-foreground">Extract difficult terms with translations in {lang.name}.</p>
      )}
    </div>
  );
}
