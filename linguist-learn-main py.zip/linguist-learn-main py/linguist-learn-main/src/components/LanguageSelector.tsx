import { useStore } from "@/lib/store";
import { LANGUAGES } from "@/lib/languages";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export function LanguageSelector() {
  const { language, setLanguage } = useStore();
  return (
    <Select value={language} onValueChange={(v) => setLanguage(v as typeof language)}>
      <SelectTrigger className="w-full bg-card">
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        {LANGUAGES.map((l) => (
          <SelectItem key={l.code} value={l.code}>
            <span className="mr-2">{l.flag}</span>
            <span className="font-medium">{l.name}</span>
            <span className="ml-2 text-muted-foreground text-xs">({l.nativeName})</span>
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
