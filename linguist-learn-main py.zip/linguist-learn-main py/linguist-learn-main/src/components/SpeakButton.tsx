import { Volume2, VolumeX } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { getLanguage } from "@/lib/languages";
import { useStore } from "@/lib/store";

export function SpeakButton({ text, className }: { text: string; className?: string }) {
  const language = useStore((s) => s.language);
  const [speaking, setSpeaking] = useState(false);

  const speak = () => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    if (speaking) {
      window.speechSynthesis.cancel();
      setSpeaking(false);
      return;
    }
    const u = new SpeechSynthesisUtterance(text);
    u.lang = getLanguage(language).bcp47;
    const voices = window.speechSynthesis.getVoices();
    const match = voices.find((v) => v.lang.startsWith(getLanguage(language).bcp47.split("-")[0]));
    if (match) u.voice = match;
    u.onend = () => setSpeaking(false);
    u.onerror = () => setSpeaking(false);
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
    setSpeaking(true);
  };

  return (
    <Button variant="ghost" size="icon" onClick={speak} className={`h-7 w-7 ${className ?? ""}`} title="Read aloud">
      {speaking ? <VolumeX className="h-3.5 w-3.5 text-primary" /> : <Volume2 className="h-3.5 w-3.5" />}
    </Button>
  );
}
